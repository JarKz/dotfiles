require("plugins")
require("colorscheme")

-- WINDOW
require("window-plugins.filetree")
require("window-plugins.dressing")
require("window-plugins.notify")
require("window-plugins.toggleterm")
require("window-plugins.telescope")
require("window-plugins.fidget")
require("window-plugins.flote")
require("window-plugins.trouble") -- It's mappings

-- ADDITIONAL FUNCTIONALITY
require("additional-functionality.mapping")
require("additional-functionality.move")
require("additional-functionality.translate")
require("additional-functionality.folding")
require("additional-functionality.search-replace")
require("additional-functionality.cursor-blinks")
require("additional-functionality.spider")

-- AUTOCMP
require("autocmp.init")

-- LSP
require("ls.mason")
require("ls.null-ls")
require("lsp-dap.init")
require("ls.config")
require("ls.highlights")

-- SYNTAX
require("syntax.treesitter")
