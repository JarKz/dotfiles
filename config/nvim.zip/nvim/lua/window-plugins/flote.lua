require("flote").setup({
	q_to_quit = true,
	window_style = "minimal",
	window_border = "solid",
	window_title = true,
})
