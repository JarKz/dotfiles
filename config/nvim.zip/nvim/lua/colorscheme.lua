vim.opt.termguicolors = true

local styles = {
	"default",
	"atlantis",
	"andromeda",
	"shusia",
	"maia",
	"espresso"
}

math.randomseed(os.time())
math.random()
math.random()
math.random()

local current_style = styles[math.random(1, #styles)]
local global = vim.g
global.sonokai_style = current_style
global.sonokai_better_performance = true
global.sonokai_diagnostic_text_highliht = true
global.sonokai_diagnostic_virtual_text = 'colored'
global.sonokai_transparent_background = true
global.sonokai_dim_inactive_windows = true
-- global.sonokai_enable_italic = true

vim.cmd("colorscheme sonokai")

local hlGroups = {
	"NormalFloat",
	"FloatBorder"
}

--- @param groups table
local make_float_transparent = function(groups)
	for _, name in ipairs(groups) do
		local hl = vim.api.nvim_get_hl(0, { name = name })
		hl.ctermbg = "NONE"
		hl.bg = "NONE"
		vim.api.nvim_set_hl(0, name, hl)
	end
end

make_float_transparent(hlGroups)
