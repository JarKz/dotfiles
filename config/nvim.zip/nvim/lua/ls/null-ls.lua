local null_ls = require("null-ls")

null_ls.setup({
	sources = {
		null_ls.builtins.formatting.google_java_format.with({
			args = { "--aosp" },
		}),

		null_ls.builtins.formatting.stylua,
		null_ls.builtins.diagnostics.eslint_d,
		null_ls.builtins.code_actions.eslint_d,
		null_ls.builtins.formatting.eslint_d,
		null_ls.builtins.completion.spell,
		null_ls.builtins.diagnostics.codespell,
		null_ls.builtins.diagnostics.misspell,
		null_ls.builtins.diagnostics.commitlint.with({
			args = {
				"-g",
				vim.fn.expand("~/.commitlintrc.js"),
				"-x",
				"/opt/homebrew/lib/node_modules/@commitlint/config-conventional",
				"--format",
				"commitlint-format-json",
			},
		}),
		-- protobuf
		-- null_ls.builtins.diagnostics.protoc_gen_lint,
		-- null_ls.builtins.diagnostics.protolint
		null_ls.builtins.diagnostics.tidy,
		-- null_ls.builtins.diagnostics.todo_comments,
		null_ls.builtins.diagnostics.yamllint,
		-- null_ls.builtins.formatting.pg_format,
	},
})
