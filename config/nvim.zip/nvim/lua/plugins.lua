local fn = vim.fn
local install_path = fn.stdpath("data") .. "/site/pack/packer/start/packer.nvim"
if fn.empty(fn.glob(install_path)) > 0 then
	Packer_bootstrap =
		fn.system({ "git", "clone", "--depth", "1", "https://github.com/wbthomason/packer.nvim", install_path })
end

return require("packer").startup(function(use)
	use("wbthomason/packer.nvim")

	-- Colorscheme
	use("sainnhe/sonokai")
	-- using macos keymap instead qwerty
	use("shvechikov/vim-keymap-russian-jcukenmac")
	use("wakatime/vim-wakatime")
	use("nvim-lua/plenary.nvim")

	-- LSP
	use({
		"williamboman/mason.nvim",
		run = ":MasonUpdate", -- :MasonUpdate updates registry contents
		"williamboman/mason-lspconfig.nvim",
		"neovim/nvim-lspconfig",
		"jose-elias-alvarez/null-ls.nvim",
	})

	-- Extensions for lsp
	use("mfussenegger/nvim-jdtls")

	-- Additional LSP functionality
	use({
		"folke/trouble.nvim",
		requires = "nvim-tree/nvim-web-devicons",
		config = function()
			require("trouble").setup({})
		end,
	})

	-- DAP
	use("mfussenegger/nvim-dap")
	use({ "rcarriga/nvim-dap-ui", requires = { "mfussenegger/nvim-dap" } })
	use("folke/neodev.nvim")

	-- AUTOCMP
	use({
		"hrsh7th/nvim-cmp",
		"hrsh7th/cmp-cmdline",           -- command line
		"hrsh7th/cmp-omni",
		"hrsh7th/cmp-buffer",            -- buffer completions
		"hrsh7th/cmp-nvim-lua",          -- nvim config completions
		"hrsh7th/cmp-nvim-lsp",          -- lsp completions
		"hrsh7th/cmp-path",              -- file path completions
		"hrsh7th/cmp-nvim-lsp-signature-help", -- function/class sugnature helping
		"saadparwaiz1/cmp_luasnip",      -- snippets completions
		"L3MON4D3/LuaSnip",
		"rafamadriz/friendly-snippets",
		"onsails/lspkind-nvim",
		{
			"tzachar/cmp-tabnine",
			run = "./install.sh",
			requires = "hrsh7th/nvim-cmp",
		},
	})
	use("windwp/nvim-ts-autotag")
	use("windwp/nvim-autopairs")

	-- WINDOW PLUGINS
	-- Telescope for finding something
	use({
		"nvim-telescope/telescope.nvim",
		requires = { { "nvim-lua/plenary.nvim" } },
	})
	use("nvim-telescope/telescope-file-browser.nvim")
	use("nvim-telescope/telescope-project.nvim")
	use("nvim-telescope/telescope-fzy-native.nvim")
	use("nvim-telescope/telescope-packer.nvim")

	-- Overriding vim.ui.select and vim.ui.insert
	use({ "stevearc/dressing.nvim" })

	-- File tree in bottom screen
	use({
		"nvim-tree/nvim-tree.lua",
		requires = {
			"nvim-tree/nvim-web-devicons",
		},
	})
	use("akinsho/toggleterm.nvim")

	-- Dashboard
	use({
		"glepnir/dashboard-nvim",
		event = "VimEnter",
		config = function()
			require("window-plugins.dashboard")
		end,
		requires = { "nvim-tree/nvim-web-devicons" },
	})
	use({
		"glepnir/dbsession.nvim",
		cmd = { "SessionSave", "SessionDelete", "SessionLoad" },
		config = function()
			require("dbsession").setup({})
		end,
	})

	-- Change default vim.notify
	use("rcarriga/nvim-notify")

	-- Display LS status as float window
	use("j-hui/fidget.nvim")
	use({
		"glepnir/galaxyline.nvim",
		branch = "main",
		config = function()
			require("window-plugins.statusline")
		end,
		requires = { "nvim-tree/nvim-web-devicons", opt = true },
	})

	-- Float note
	use({
		"JellyApple102/flote.nvim",
	})

	use({ "ellisonleao/glow.nvim" })

	-- ADDITIONAL FUNCTIONALITY
	use({
		"folke/which-key.nvim",
	})
	use({
		"numToStr/Comment.nvim",
		config = function()
			require("additional-functionality.commentary")
		end,
	})
	use("edluffy/specs.nvim")
	use("booperlv/nvim-gomove")
	use("uga-rosa/translate.nvim")
	use({
		"wintermute-cell/gitignore.nvim",
		requires = {
			"nvim-telescope/telescope.nvim",
		},
	})
	use({ "chrisgrieser/nvim-spider" })

	-- Pretty folding
	use({ "kevinhwang91/nvim-ufo", requires = "kevinhwang91/promise-async" })

	-- use({ "roobert/search-replace.nvim" })
	use({ "JarKz/search-replace-additional-configuration.nvim", branch = "dev" })

	-- SYNTAX HIGHLIHGT
	use({
		"nvim-treesitter/nvim-treesitter",
		run = ":TSUpdate",
	})
	-- Highlight similar or logical keyword pairs (e.g. for { -> } or break -> while)
	use("RRethy/vim-illuminate")

	-- AUTONOMOUS
	use({
		"Pocco81/auto-save.nvim",
		-- for avoid duplicate of message
		branch = "dev",
		config = function()
			require("autonomous.autosave")
		end,
	})

	if Packer_bootstrap then
		require("packer").sync()
	end
end)
