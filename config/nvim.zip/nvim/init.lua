require("neodev").setup({
	library = { plugins = { "nvim-dap-ui" }, types = true },
})

-- Disable perl provider
vim.g.loaded_perl_provider = 0

package.path = "{$HOME}/.config/nvim/lua/?.lua;"

vim.opt.guicursor = {
	n = "block",
	v = "block",
	c = "block",
	i = "ver25",
	ci = "ver25",
	ve = "ver25",
	r = "hor20",
	cr = "hor20",
	o = "hor50",
	a = "blinkwait700-blinkoff400-blinkon250-Cursor/lCursor",
	sm = "block-blinkwait175-blinkoff150-blinkon175",
}

vim.opt.mouse = "a"
vim.opt.tabstop = 4
vim.opt.shiftwidth = 4

vim.opt.updatetime = 2000

vim.wo.number = true
vim.opt.relativenumber = true

-- setup of visibility of tabs, spaces, indents and trail spaces
vim.opt.listchars = "eol:\\u23CE,tab:>·,trail:~,extends:>,precedes:<,space:⚬"
vim.opt.list = true

-- Switch language
-- if you use windows or linux — set jcukenwim, else you use macos — jcukenmac
-- vim.opt.keymap = "russian-jcukenwin"
vim.opt.keymap = "russian-jcukenmac"
vim.opt.iminsert = 0
vim.opt.imsearch = 0

require("init-configurations")
