local glow = require("glow")

local curved = { "╭", "─", "╮", "│", "╯", "─", "╰", "│" }

glow.setup({
	glow_path = "/opt/homebrew/bin/glow",
	install_path = "~/.local/bin",
	border = curved,
	-- style = "dark",
	pager = false,
	width = 100,
	height = 120,
	-- width_ratio = 0.7,
	-- height_ratio = 0.7,
})
